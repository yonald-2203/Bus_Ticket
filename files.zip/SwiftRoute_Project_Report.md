# SwiftRoute — Bus Ticket Booking System
## Complete Project Report

---

## 1. Executive Summary

SwiftRoute is a full-stack bus ticket booking web application built using ASP.NET Core 8 (backend) and Angular 21 (frontend). It enables customers to search and book bus tickets online, bus operators to manage their fleet and schedules, and administrators to oversee the entire platform. The system implements industry-standard security, role-based access control, real-time seat management, and a full audit trail.

---

## 2. Project Objectives

- Build a production-grade three-tier web application from scratch
- Implement secure authentication and role-based authorization
- Handle real-world concurrency challenges (double-seat booking prevention)
- Follow clean architecture principles (separation of concerns)
- Produce testable, maintainable code with comprehensive unit tests
- Deliver a professional user interface comparable to commercial platforms like RedBus

---

## 3. Technology Stack

| Layer | Technology | Version | Purpose |
|---|---|---|---|
| Backend Framework | ASP.NET Core Web API | 8.0 | REST API server |
| Language (Backend) | C# | 12 | Business logic |
| ORM | Entity Framework Core | 8.0 | Database operations |
| Database | Microsoft SQL Server | 2019+ | Data persistence |
| Authentication | JWT Bearer Tokens | — | Stateless auth |
| Password Security | ASP.NET Identity Hasher | — | PBKDF2 hashing |
| API Documentation | Swagger / OpenAPI | v3 | Interactive API docs |
| Frontend Framework | Angular | 21.2 | Single Page Application |
| Language (Frontend) | TypeScript | 5.9 | Type-safe frontend |
| Styling | Tailwind CSS | 3.4 | Utility-first CSS |
| HTTP Client | Angular HttpClient | — | API communication |
| State Management | Angular Signals | — | Reactive UI state |
| Testing (Frontend) | Jasmine + Karma | — | Unit testing |
| Testing (Backend) | xUnit + Moq | — | Unit testing |

---

## 4. System Architecture

The application follows a layered architecture pattern:

```
Angular Frontend (Port 4200)
    ↓  HTTP + JWT Bearer Token
ASP.NET Core Web API (Port 5299)
    ↓  Dependency Injection
Service Layer (Business Logic)
    ↓  Generic Repository Pattern
Entity Framework Core (ORM)
    ↓  SQL Queries
SQL Server Database
```

### 4.1 Backend Layers

**Controllers** — Receive HTTP requests, extract user claims, call services, return HTTP responses. Never contain business logic.

**Services** — All business rules live here. Validate input, enforce ownership, coordinate transactions.

**Repository** — Generic `IRepository<T>` abstracts all database operations. One implementation covers all 10 entities.

**Models/Entities** — Plain C# classes mapped to database tables via EF Core.

**Middlewares** — Cross-cutting concerns: Audit logging (every write), Global exception handling (all errors).

### 4.2 Frontend Layers

**Components** — Standalone Angular components. Each page is a self-contained unit.

**Services** — Inject HttpClient, call API endpoints, return Observables.

**Guards** — Route protection: authGuard (must be logged in), noAuthGuard (must not be logged in), roleGuard (must have specific role).

**Interceptors** — authInterceptor automatically attaches JWT token to every outgoing request and handles 401 responses.

**Signals** — Angular's new reactivity system. `signal()` creates reactive state, `computed()` derives values automatically.

---

## 5. Database Design

### 5.1 Entity Relationship Summary

The database contains 11 tables with carefully designed foreign key relationships:

- **Users** → One-to-one → **BusOperators** (when role = Operator)
- **BusOperators** → One-to-many → **Buses**
- **BusOperators** → One-to-many → **BusRoutes**
- **Buses** → One-to-many → **BusSchedules**
- **BusRoutes** → One-to-many → **BusSchedules**
- **BusRoutes** → One-to-many → **RouteStops** → Many-to-one → **Stops**
- **BusSchedules** → One-to-many → **Bookings**
- **Users** → One-to-many → **Bookings**
- **Bookings** → One-to-many → **BookingPassengers**
- **Bookings** → One-to-one → **Payments**
- **AuditLogs** — standalone, not related (stores system activity)

### 5.2 BaseEntity Pattern

All main entities inherit from `BaseEntity`:
```csharp
public abstract class BaseEntity {
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAtUtc { get; set; }
    public bool IsDeleted { get; set; }
    public byte[]? RowVersion { get; set; }  // Concurrency token
}
```

`RowVersion` is used as a concurrency token — EF Core uses it to detect when two users try to update the same record simultaneously.

### 5.3 Key Constraints

- Username and Email are **unique indexed**
- Bus Code is **unique per operator** (composite index on OperatorId + Code)
- Route Code is **unique per operator**
- Departure time is **unique per bus** (no bus can have two schedules at same time)
- RouteStop Order is **unique per route**
- Stop Name is **unique per city**

---

## 6. Authentication & Security

### 6.1 Registration Flow

1. User submits username, email, password, full name, role
2. If role = "Operator" → saved as "PendingOperator"
3. Password hashed with PBKDF2 (ASP.NET Identity PasswordHasher)
4. JWT token issued with role embedded in claims
5. Frontend stores token in localStorage

### 6.2 JWT Token Structure

```
Header: { alg: "HS256", typ: "JWT" }
Payload: {
    sub: "user-guid",
    unique_name: "username",
    email: "user@email.com",
    role: "Admin|Operator|Customer|PendingOperator",
    jti: "unique-token-id",
    exp: 1234567890  (expiry timestamp)
}
Signature: HMAC-SHA256(base64Header + "." + base64Payload, secretKey)
```

### 6.3 Authorization Matrix

| Endpoint | Admin | Operator | Customer | PendingOperator |
|---|---|---|---|---|
| POST /api/buses | ✅ | ✅ (own) | ❌ | ❌ |
| GET /api/schedules | ✅ | ✅ (own) | ❌ | ❌ |
| POST /api/bookings | ❌ | ❌ | ✅ | ❌ |
| GET /api/auditlogs | ✅ | ❌ | ❌ | ❌ |
| POST /api/operator-approvals/{id}/approve | ✅ | ❌ | ❌ | ❌ |

### 6.4 Concurrency & Race Conditions

**Problem:** Two customers try to book Seat 5A at the same time.

**Solution:** BookingService uses a **Serializable database transaction**:
```csharp
await using var tx = await _db.Database.BeginTransactionAsync(IsolationLevel.Serializable, ct);
// Lock and check — no other transaction can read/write these rows
var takenSeats = await _db.BookingPassengers
    .Where(bp => requestedSeats.Contains(bp.SeatNo))
    .Join(_db.Bookings, ...)
    .ToListAsync(ct);
if (takenSeats.Any()) throw new InvalidOperationException("Seats already taken");
// Only one transaction succeeds, the other gets an exception
await tx.CommitAsync(ct);
```

---

## 7. Backend File-by-File Explanation

### Program.cs
The application entry point. Configures the DI container, registers all services, sets up JWT authentication, configures the middleware pipeline. Order matters:
`UseCors → AuditMiddleware → GlobalExceptionMiddleware → UseAuthentication → UseAuthorization → MapControllers`

### AppDbContext.cs
Inherits from `DbContext`. Contains `DbSet<T>` for every entity. `OnModelCreating()` configures all relationships, indexes, constraints, and the RowVersion concurrency token.

### BaseEntity.cs
Abstract base class giving every entity: GUID primary key, created/updated timestamps, soft-delete flag, and RowVersion concurrency token.

### Repository.cs / IRepository.cs
Generic repository implementing `GetByIdAsync`, `GetAllAsync`, `FindAsync` (with expression filter), `AddAsync`, `UpdateAsync`, `RemoveAsync`, `ExistsAsync`. Registered as `IRepository<T>` → `Repository<T>` so DI resolves automatically for any entity type.

### TokenService.cs
Generates JWT tokens. Creates a `JwtSecurityToken` with claims (userId, username, email, role), signs with HMAC-SHA256, returns the serialized token string and expiry time.

### PasswordService.cs
Wraps `PasswordHasher<User>` from ASP.NET Identity. `Hash()` generates a salted PBKDF2 hash. `Verify()` compares plaintext against stored hash.

### UserService.cs
Creates users after checking username/email uniqueness. Hashes password before saving.

### BusService.cs
All bus CRUD operations with ownership checks. Operators can only see/edit their own buses. Admin can see all. `GetAllSecuredAsync` and `GetByIdSecuredAsync` enforce this.

### BookingService.cs
Most complex service. Creates bookings with full validation: schedule exists, not cancelled, bus available, valid seats, no duplicates. Uses serializable transaction for seat locking.

### AuditMiddleware.cs
Runs on every request. Measures duration with Stopwatch. After the request completes, if it was a write operation (POST/PUT/PATCH/DELETE) on an `/api/` route, writes an AuditLog record. If an unhandled exception occurs, writes an Error log with full stack trace.

### GlobalExceptionMiddleware.cs
Catches all unhandled exceptions. Returns a clean JSON error response instead of HTML error pages. Logs the error with ILogger.

### AuditLogsController.cs
Single endpoint: `GET /api/auditlogs`. Admin only. Accepts query parameters for filtering by type, username, entity, date range. Returns paginated results.

### OperatorApprovalController.cs
Three endpoints: list pending operators, approve (promotes role to Operator + creates BusOperator profile), reject (sets role to Customer).

---

## 8. Frontend File-by-File Explanation

### app.config.ts
Angular's root configuration. Registers the router (with view transitions), HTTP client (with the auth interceptor), and animations.

### app.routes.ts
Defines all URL routes. Uses lazy loading (`loadComponent`) so each page is only downloaded when needed. Routes are protected with `canActivate: [authGuard]` or `canActivate: [authGuard, roleGuard('Admin')]`.

### auth.interceptor.ts
A functional HTTP interceptor. Before every request goes out, it reads the JWT token from AuthService and adds `Authorization: Bearer <token>` header. If the response is 401 (Unauthorized), it calls `auth.logout()` and redirects to login.

### auth.service.ts
Central authentication state manager. Uses `signal<CurrentUser | null>` to hold the logged-in user. Persists to localStorage so login survives page refresh. Exposes computed signals: `isLoggedIn`, `role`, `isAdmin`, `isOperator`, `isCustomer`.

### guards.ts
- `authGuard` — blocks access if not logged in, redirects to /auth/login
- `noAuthGuard` — redirects already-logged-in users away from login/register pages
- `roleGuard(roles)` — allows access only if user has one of the specified roles

### booking-state.service.ts
Holds the in-flight booking data across multiple pages (seat selection → passenger form → payment). Uses signal to store `BookingDraft` containing the chosen schedule, selected seats, and passenger details.

### audit-log.service.ts
Calls `GET /api/auditlogs` with HttpParams built from filter options. Returns `Observable<PagedAuditLogResult>`.

### operator-approval.service.ts
Calls the three operator approval endpoints: getPending(), approve(id, dto), reject(id).

---

## 9. Key Angular Concepts Used

### Signals
```typescript
count = signal(0);             // writable signal
double = computed(() => count() * 2);  // derived signal
count.set(5);                  // update
count.update(v => v + 1);      // transform
```
Signals are Angular's modern alternative to RxJS Subjects. They update the DOM automatically when their value changes.

### Standalone Components
Every component has `standalone: true` and declares its own `imports: []`. No NgModule required. This is Angular 17+ style.

### @if / @for Block Syntax
Angular 17+ template syntax:
```html
@if (loading()) { <spinner/> }
@for (item of items(); track item.id) { <div>{{item.name}}</div> }
```
Replaces `*ngIf` and `*ngFor` directives.

### Lazy Loading
```typescript
loadComponent: () => import('./pages/home/home.component')
    .then(m => m.HomeComponent)
```
The component JavaScript is only downloaded when the user navigates to that route.

---

## 10. End-to-End User Flows

### Customer Booking Flow
1. Register/Login → JWT stored in localStorage
2. Home page: select From city, To city, Date → `GET /api/schedules/search-by-keys`
3. Search results: list of buses with prices
4. Click "Book Now" → Seat selection page
5. `GET /api/schedules/{id}/seats` → shows available/booked seats
6. Select seats → Passenger details form
7. If Passenger 1 = "Me" → auto-fill from `auth.currentUser().fullName`
8. Submit → `POST /api/bookings` → Booking created as **Pending**
9. Payment page → click Pay → `POST /api/bookings/{id}/pay` → status → **Confirmed**
10. View in My Bookings, can Cancel if Pending/Confirmed

### Operator Approval Flow
1. New user registers with role "Operator" → saved as "PendingOperator"
2. Gets JWT with role = "PendingOperator", redirected to /home
3. Cannot access /operator routes (roleGuard blocks)
4. Admin logs in → sees "Operator Approvals" card on dashboard
5. Admin opens `/admin/operator-approvals` → sees pending list
6. Admin clicks Approve → fills company name → `POST /api/operator-approvals/{id}/approve`
7. Backend: updates User.Role = "Operator", creates BusOperator profile
8. Operator logs in again → gets new JWT with role = "Operator" → can access /operator

---

## 11. Design Patterns Used

| Pattern | Where Used | Why |
|---|---|---|
| Repository Pattern | `IRepository<T>` | Abstracts DB access, enables unit testing with mocks |
| Dependency Injection | Throughout backend | Loose coupling, testability |
| Middleware Pipeline | AuditMiddleware, GlobalExceptionMiddleware | Cross-cutting concerns separated from business logic |
| DTOs (Data Transfer Objects) | All API inputs/outputs | Separate API contract from internal models |
| Interceptor Pattern | authInterceptor (Angular) | Centralized token attachment and 401 handling |
| Factory Pattern | `DbSeeder` | Creates initial data in development |
| Observer Pattern | Angular Observables, Signals | Reactive data flow |
| Guard Pattern | Angular Route Guards | Declarative route protection |

---

## 12. Challenges & Solutions

| Challenge | Solution |
|---|---|
| Double-seat booking | Serializable DB transaction with row locking |
| Operator ownership scoping | All service methods accept userId + role, filter accordingly |
| Cross-page booking state | BookingStateService with signal holds draft across 3 pages |
| Token expiry handling | authInterceptor catches 401, auto-logs out |
| TypeScript type errors for PendingOperator | Exported `UserRole` union type used across all interfaces |
| Angular build errors (RouterLink unused) | Removed from imports array when not used in template |

---

## 13. Future Enhancements

- Real payment gateway integration (Razorpay/Stripe)
- Email notifications on booking confirmation/cancellation
- PDF e-ticket generation
- Live tracking with SignalR websockets
- Admin analytics dashboard with charts
- Mobile app (Angular + Capacitor)
- Redis caching for frequently queried schedules
- Docker containerization for deployment
