# SwiftRoute — Complete 12-Hour Study Guide
### "Study this and answer every question your teacher asks"

---

# PART 1 — BACKEND DEEP DIVE

---

## Chapter 1: What is ASP.NET Core and Why?

**ASP.NET Core** is Microsoft's open-source, cross-platform web framework. It runs on .NET 8 (the latest LTS version).

**Why we used it:**
- Performance: One of the fastest frameworks in the world (TechEmpower benchmarks)
- Built-in Dependency Injection
- Middleware pipeline is simple and powerful
- EF Core integrates seamlessly
- JWT auth support is native

**How an ASP.NET Core request works:**
```
HTTP Request arrives
    ↓
Middleware 1: HTTPS Redirection
Middleware 2: CORS
Middleware 3: AuditMiddleware     ← we added this
Middleware 4: GlobalExceptionMiddleware  ← we added this
Middleware 5: UseAuthentication   ← reads JWT, sets User principal
Middleware 6: UseAuthorization    ← checks [Authorize] attributes
Middleware 7: MapControllers      ← routes to correct controller method
    ↓
Controller Action Method
    ↓
Service Layer
    ↓
Repository → EF Core → SQL Server
    ↓
HTTP Response
```

---

## Chapter 2: Program.cs — The Entry Point

Everything starts in `Program.cs`. It has two phases:

**Phase 1: Builder (registering services)**
```csharp
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();           // MVC controllers
builder.Services.AddDbContext<AppDbContext>(...);  // Database
builder.Services.AddScoped<IBusService, BusService>();  // DI
```

**Phase 2: App (middleware pipeline)**
```csharp
var app = builder.Build();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();
```

**Key concept — Service Lifetimes:**
- `AddScoped` — one instance per HTTP request (we use this for all services)
- `AddSingleton` — one instance for entire app lifetime
- `AddTransient` — new instance every time it's requested

**Why Scoped for services?** Because each HTTP request is independent. A Scoped service is created fresh for each request, so user A's request can't affect user B's data.

---

## Chapter 3: Entity Framework Core & AppDbContext

**EF Core** is an Object-Relational Mapper (ORM). It lets you work with the database using C# objects instead of writing SQL.

**AppDbContext** is our database session manager. It:
1. Holds `DbSet<T>` for each table
2. Configures relationships in `OnModelCreating()`
3. Tracks changes (change tracker)
4. Saves to database with `SaveChangesAsync()`

**Code-First approach** — we define C# models, EF Core generates the SQL schema.

**Migration commands:**
```bash
dotnet ef migrations add MigrationName  # creates migration file
dotnet ef database update               # applies to DB
```

**Important configuration in AppDbContext:**

```csharp
// Unique index example
e.HasIndex(u => u.Username).IsUnique();

// Foreign key relationship
e.HasOne(b => b.Operator)
 .WithMany(o => o.Buses)
 .HasForeignKey(b => b.OperatorId)
 .OnDelete(DeleteBehavior.Cascade);  // delete operator → delete all their buses

// Precision for money
e.Property(b => b.TotalAmount).HasPrecision(10, 2);  // e.g. 99999999.99

// Concurrency token
rowVersion.IsConcurrencyToken = true;
```

**Delete Behaviors:**
- `Cascade` — deleting parent deletes children (Bus deleted → Schedules deleted)
- `Restrict` — cannot delete parent if children exist (Stop cannot be deleted if RouteStop uses it)

---

## Chapter 4: BaseEntity and Why It Matters

```csharp
public abstract class BaseEntity {
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAtUtc { get; set; }
    public bool IsDeleted { get; set; }
    public byte[]? RowVersion { get; set; }
}
```

**Why GUID instead of int?**
- GUIDs are globally unique — safe to generate client-side
- No sequential guessability (attacker can't try `/api/bookings/1`, `/api/bookings/2`)
- Works perfectly in distributed systems

**Why UTC time?**
- UTC is timezone-neutral. If your server is in Chennai and user is in London, storing UTC means the time is unambiguous.
- Always store UTC, display in local timezone on frontend.

**RowVersion (Concurrency Token):**
When two users try to update the same record simultaneously:
1. User A reads Booking (RowVersion = 0x001)
2. User B reads same Booking (RowVersion = 0x001)
3. User A updates → DB updates RowVersion to 0x002
4. User B tries to update with old RowVersion 0x001 → EF Core throws `DbUpdateConcurrencyException`
This prevents "lost update" problems.

---

## Chapter 5: Generic Repository Pattern

```csharp
public interface IRepository<TEntity> where TEntity : class {
    Task<TEntity?> GetByIdAsync(Guid id, CancellationToken ct);
    Task<IEnumerable<TEntity>> GetAllAsync(CancellationToken ct);
    Task<IEnumerable<TEntity>> FindAsync(Expression<Func<TEntity, bool>> predicate, CancellationToken ct);
    Task<TEntity> AddAsync(TEntity entity, CancellationToken ct);
    Task UpdateAsync(TEntity entity, CancellationToken ct);
    Task RemoveAsync(TEntity entity, CancellationToken ct);
}
```

**Why Repository Pattern?**
1. **Testability** — in unit tests, replace real repository with `Mock<IRepository<Bus>>()`
2. **No duplication** — one implementation works for all 10 entities
3. **Separation** — services don't know/care about how data is stored

**The `where TEntity : class` constraint** — TEntity must be a reference type (class), not a value type (int, struct). This allows EF Core to track it.

**Expression predicate in FindAsync:**
```csharp
// This:
var buses = await _buses.FindAsync(b => b.OperatorId == operatorId, ct);
// Translates to SQL:
// SELECT * FROM Buses WHERE OperatorId = 'guid'
```

**`AsNoTracking()`** — used for read-only queries. EF Core doesn't track these entities in its change tracker, making reads faster.

---

## Chapter 6: JWT Authentication — Complete Flow

**JWT = JSON Web Token**. A self-contained way to transmit user identity.

**Structure:** `header.payload.signature` (base64 encoded, dot-separated)

**TokenService.cs generates the token:**
```csharp
var claims = new List<Claim> {
    new(JwtRegisteredClaimNames.Sub, user.Id.ToString()),  // subject = user id
    new(ClaimTypes.Role, user.Role),                       // role for authorization
    new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()) // unique token id
};
var token = new JwtSecurityToken(
    signingCredentials: new SigningCredentials(
        new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey)),
        SecurityAlgorithms.HmacSha256));  // signed with our secret
```

**Program.cs validates incoming tokens:**
```csharp
options.TokenValidationParameters = new TokenValidationParameters {
    ValidateIssuerSigningKey = true,     // must be signed with our key
    IssuerSigningKey = ...,              // our secret key
    ValidateLifetime = true,             // must not be expired
    ClockSkew = TimeSpan.FromMinutes(1)  // allow 1 min clock difference
};
```

**In controllers, reading the user:**
```csharp
private Guid CurrentUserId => Guid.Parse(
    User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub"));
private string CurrentRole => User.FindFirstValue(ClaimTypes.Role);
```

**Why JWT over sessions?**
- **Stateless** — server doesn't store session data. Any server in a cluster can validate any token.
- **Self-contained** — role is inside the token, no DB lookup needed per request
- **Mobile-friendly** — browsers + mobile apps both can send in headers

---

## Chapter 7: Password Security

**PasswordService.cs** wraps `PasswordHasher<User>` from ASP.NET Identity.

**How PBKDF2 hashing works:**
1. Generate a random **salt** (16 bytes)
2. Apply hash function 100,000 times (iterations make brute-force slow)
3. Output: `$2a$10$salt+hash` format
4. Store this string in database

**Why not MD5 or SHA256?**
- MD5/SHA256 are fast — attackers can try billions of passwords per second
- PBKDF2 is intentionally slow — makes brute-force attacks infeasible
- Even if DB is stolen, plaintext passwords cannot be recovered

**Verify process:**
```csharp
var result = _hasher.VerifyHashedPassword(user, user.PasswordHash, plainPassword);
// EF Core extracts the salt from stored hash, re-hashes the input, compares
```

---

## Chapter 8: Role-Based Authorization in Detail

**Roles defined in Roles.cs:**
```csharp
public static class Roles {
    public const string Admin           = "Admin";
    public const string Operator        = "Operator";
    public const string Customer        = "Customer";
    public const string PendingOperator = "PendingOperator";
}
```

**Applied on controllers:**
```csharp
[Authorize(Roles = Roles.Admin)]          // only Admin
[Authorize(Roles = $"{Roles.Admin},{Roles.Operator}")]  // Admin or Operator
[Authorize]                               // any logged-in user
[AllowAnonymous]                          // no auth required
```

**Ownership check (Operator can only see own buses):**
```csharp
public async Task<IEnumerable<BusResponseDto>> GetAllSecuredAsync(Guid userId, string role, CancellationToken ct) {
    if (role == Roles.Admin) {
        return (await _buses.GetAllAsync(ct)).Select(Map);  // admin sees all
    }
    // Operator: find their profile first, then filter buses
    var op = (await _operators.FindAsync(o => o.UserId == userId, ct)).FirstOrDefault();
    if (op == null) return Enumerable.Empty<BusResponseDto>();
    var list = await _buses.FindAsync(b => b.OperatorId == op.Id, ct);
    return list.Select(Map);
}
```

---

## Chapter 9: Booking Service — The Most Complex Part

**The booking creation has 7 validation steps:**

1. At least one passenger required
2. No duplicate seat numbers in same request
3. Schedule exists in database
4. Schedule not cancelled by operator
5. Bus status = Available (not Under Repair or Not Available)
6. All requested seat numbers are valid for this bus (within 1 to totalSeats)
7. Open Serializable transaction → lock and check seats not already booked

**Serializable Transaction:**
```csharp
await using var tx = await _db.Database.BeginTransactionAsync(
    IsolationLevel.Serializable, ct);

// This query locks the rows it touches
var takenSeats = await _db.BookingPassengers
    .Where(bp => requestedSeats.Contains(bp.SeatNo))
    .Join(_db.Bookings, bp => bp.BookingId, b => b.Id,
          (bp, b) => new { bp.SeatNo, b.Status, b.ScheduleId })
    .Where(x => x.ScheduleId == dto.ScheduleId
             && x.Status != BookingStatus.Cancelled
             && x.Status != BookingStatus.Refunded)
    .Select(x => x.SeatNo)
    .ToListAsync(ct);

if (takenSeats.Any())
    throw new InvalidOperationException($"Seats already taken: {string.Join(", ", takenSeats)}");

// Create booking and passengers...
await tx.CommitAsync(ct);
```

**IsolationLevel.Serializable** is the strictest level. It prevents:
- Dirty reads (reading uncommitted data)
- Non-repeatable reads (data changed between two reads in same transaction)
- Phantom reads (new rows appearing between two queries)

---

## Chapter 10: Audit & Error Logging System

**AuditMiddleware** runs on every request:

```csharp
public async Task InvokeAsync(HttpContext ctx) {
    var sw = Stopwatch.StartNew();
    try {
        await _next(ctx);      // run rest of pipeline
        sw.Stop();
        // Log only write operations on /api routes
        if (ctx.Request.Path.StartsWithSegments("/api") &&
            ctx.Request.Method is "POST" or "PUT" or "PATCH" or "DELETE") {
            await WriteAuditAsync(ctx, sw.ElapsedMilliseconds);
        }
    }
    catch (Exception ex) {
        sw.Stop();
        await WriteErrorAsync(ctx, ex, sw.ElapsedMilliseconds);
        throw;  // re-throw so GlobalExceptionMiddleware handles it
    }
}
```

**AuditLog record includes:**
- LogType: "Audit" (admin ops) or "Error" (exceptions)
- Action: HTTP method (POST, DELETE, etc.)
- Description: human-readable ("Created → /api/buses [201]")
- Username, UserRole: from JWT claims
- EntityType: inferred from URL path (/buses → "Bus")
- StatusCode, DurationMs: performance tracking
- Detail: full stack trace (Error logs only)

**Why separate Audit from Error logs?**
- Audit = intentional admin/operator actions (business trail)
- Error = unintended system failures (debugging)
- Admin can filter by type in the UI

---

## Chapter 11: Operator Approval Flow — Backend

**New role added: PendingOperator**

**Registration (AuthController.cs):**
```csharp
var assignedRole = requestedRole == Roles.Operator
    ? Roles.PendingOperator   // ← NEW: don't give Operator access immediately
    : requestedRole;
```

**OperatorApprovalController.cs — three endpoints:**

1. `GET /api/operator-approvals` — lists all Users where Role = "PendingOperator"
2. `POST /api/operator-approvals/{id}/approve` — promotes User.Role to "Operator", creates BusOperator profile with company name
3. `POST /api/operator-approvals/{id}/reject` — sets User.Role back to "Customer"

**All three endpoints have `[Authorize(Roles = Roles.Admin)]`** — only Admin can call them.

---

# PART 2 — FRONTEND DEEP DIVE

---

## Chapter 12: Angular 21 Architecture

**Standalone Components** — Angular 17+ style. No NgModule needed.

```typescript
@Component({
    selector: 'app-home',
    standalone: true,           // ← standalone
    imports: [CommonModule, ReactiveFormsModule],  // ← self-contained imports
    template: `...`
})
export class HomeComponent {}
```

**Why standalone?**
- Simpler — no barrel files, no NgModule to maintain
- Better tree-shaking (unused imports removed from bundle)
- Each component clearly declares what it needs

**Lazy Loading with loadComponent:**
```typescript
{
    path: 'home',
    loadComponent: () =>
        import('./pages/home/home.component')
        .then(m => m.HomeComponent)
}
```
The JS bundle for HomeComponent is only downloaded when user navigates to /home. This makes initial page load much faster.

---

## Chapter 13: Angular Signals — The New State Management

**Signals** replace the need for RxJS BehaviorSubject for local state.

```typescript
// Create a signal
count = signal(0);

// Read a signal (the () call reads its current value)
console.log(count());  // → 0

// Update a signal
count.set(5);
count.update(v => v + 1);  // → 6

// Derived signal (auto-updates when dependency changes)
double = computed(() => count() * 2);  // → 12

// Signal in template
<p>{{ count() }}</p>  // ← reactive, auto-updates DOM
```

**In AuthService:**
```typescript
private _currentUser = signal<CurrentUser | null>(this.loadFromStorage());
currentUser = this._currentUser.asReadonly();  // expose read-only
isLoggedIn = computed(() => !!this._currentUser());
role = computed(() => this._currentUser()?.role ?? null);
isAdmin = computed(() => this.role() === 'Admin');
```

When `_currentUser` changes (login/logout), all computed values (`isLoggedIn`, `role`, `isAdmin`) and any template using `auth.isLoggedIn()` automatically update.

---

## Chapter 14: HTTP Interceptor

```typescript
export const authInterceptor: HttpInterceptorFn = (req, next) => {
    const auth = inject(AuthService);
    const router = inject(Router);

    const token = auth.getToken();

    // Clone request with Authorization header
    const authReq = token
        ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } })
        : req;

    return next(authReq).pipe(
        catchError((err: HttpErrorResponse) => {
            if (err.status === 401) {
                auth.logout();            // clear token
                router.navigate(['/auth/login']);  // redirect
            }
            return throwError(() => err);
        })
    );
};
```

**Why interceptor instead of adding header in every service?**
- DRY principle — one place handles token attachment
- All services benefit automatically
- 401 handling is centralized
- If token format ever changes, update one file

**Registered in app.config.ts:**
```typescript
provideHttpClient(withInterceptors([authInterceptor]))
```

---

## Chapter 15: Route Guards

**authGuard** — protects routes that require login:
```typescript
export const authGuard: CanActivateFn = () => {
    const auth = inject(AuthService);
    if (auth.isLoggedIn() && !auth.isTokenExpired()) return true;
    return inject(Router).createUrlTree(['/auth/login']);
};
```

**noAuthGuard** — prevents logged-in users from accessing login/register:
```typescript
export const noAuthGuard: CanActivateFn = () => {
    const auth = inject(AuthService);
    if (!auth.isLoggedIn()) return true;
    // Redirect based on role
    const role = auth.role();
    if (role === 'Admin') return router.createUrlTree(['/admin']);
    if (role === 'Operator') return router.createUrlTree(['/operator']);
    return router.createUrlTree(['/home']);
};
```

**roleGuard** — protects role-specific routes:
```typescript
export function roleGuard(...allowedRoles: string[]): CanActivateFn {
    return () => {
        const role = inject(AuthService).role();
        if (role && allowedRoles.includes(role)) return true;
        return inject(Router).createUrlTree(['/home']);
    };
}
```

**Applied in routes:**
```typescript
{ path: 'admin', canActivate: [authGuard, roleGuard('Admin')], ... }
```

---

## Chapter 16: BookingStateService — Cross-Page State

**The problem:** A customer's booking spans 3 pages:
1. Seat Selection — choose seats
2. Passenger Form — enter names
3. Payment — confirm and pay

How do you pass data between these pages without URL query params?

**Solution: BookingStateService with signal:**
```typescript
@Injectable({ providedIn: 'root' })
export class BookingStateService {
    private _draft = signal<BookingDraft | null>(null);
    readonly draft = this._draft.asReadonly();

    setSchedule(schedule: ScheduleResponse): void {
        this._draft.set({ schedule, selectedSeats: [], passengers: [] });
    }
    setSeats(seats: string[]): void {
        this._draft.update(d => d ? { ...d, selectedSeats: seats } : null);
    }
    setPassengers(passengers: BookingPassengerDto[]): void {
        this._draft.update(d => d ? { ...d, passengers } : null);
    }
    clear(): void { this._draft.set(null); }
}
```

Because it's `providedIn: 'root'`, it's a singleton — same instance exists throughout the app session. All three pages inject it and read/write the same signal.

---

## Chapter 17: Reactive Forms

Used in: login, register, passenger form, manage buses, manage routes, manage schedules.

```typescript
form = this.fb.group({
    username: ['', [Validators.required]],             // initial value + validators
    password: ['', [Validators.required, Validators.minLength(6)]],
});
```

**Validation check:**
```typescript
isInvalid(field: string): boolean {
    const c = this.form.get(field);
    return !!(c?.invalid && c?.touched);  // invalid AND user has touched it
}
```

**FormArray (for dynamic passenger rows):**
```typescript
form = this.fb.group({ passengers: this.fb.array([]) });

get passengersArray(): FormArray {
    return this.form.get('passengers') as FormArray;
}

// Add a row:
passengersArray.push(this.fb.group({
    name: ['', Validators.required],
    age: [null],
    seatNo: [seat]
}));
```

**Template binding:**
```html
<form [formGroup]="form" (ngSubmit)="onSubmit()">
    <div formArrayName="passengers">
        @for (pg of passengersArray.controls; track $index) {
            <div [formGroupName]="$index">
                <input formControlName="name" />
            </div>
        }
    </div>
</form>
```

---

## Chapter 18: Angular Proxy Configuration

**Problem:** Angular dev server runs on port 4200. Backend on port 5299. Same-origin policy blocks cross-origin requests from browser.

**Solution:** Angular dev proxy in `proxy.config.json`:
```json
{
    "/api": {
        "target": "http://localhost:5299",
        "secure": false,
        "changeOrigin": true
    }
}
```

**How it works:**
```
Browser → Angular (4200) → calls /api/buses
Angular dev server sees /api → proxies to http://localhost:5299/api/buses
Response comes back through Angular → back to browser
Browser never knows about port 5299
```

**environment.ts:**
```typescript
export const environment = {
    production: false,
    apiUrl: '/api'    // not localhost:5299 — the proxy handles that
};
```

---

# PART 3 — CONCEPTS QUICK REFERENCE

---

## Backend Concepts — Complete List

| Concept | Definition |
|---|---|
| REST API | Architectural style using HTTP verbs (GET/POST/PUT/DELETE) for resources |
| ASP.NET Core | Microsoft's cross-platform web framework |
| Controller | Class that handles HTTP requests and returns responses |
| [ApiController] | Attribute enabling automatic model validation, binding |
| [Route("api/[controller]")] | URL prefix for all actions in the controller |
| Dependency Injection (DI) | Framework provides dependencies, not the class itself |
| IRepository<T> | Generic interface abstracting database operations |
| DbContext | EF Core's database session — unit of work |
| Entity Framework Core | ORM that converts between C# objects and SQL |
| Code-First | Define models in C#, generate DB schema from them |
| Migration | Versioned change to the database schema |
| DbSet<T> | Represents a table in the database |
| LINQ | Language-Integrated Query — C# syntax for querying data |
| AsNoTracking() | Read-only query, faster because EF doesn't track changes |
| Include() | Eager loading — load related entities in same query |
| GUID | Globally Unique Identifier — 128-bit UUID used as primary key |
| JWT | JSON Web Token — self-contained auth token |
| Bearer Token | HTTP Authorization scheme: "Authorization: Bearer <token>" |
| Claims | Key-value pairs inside a JWT (role, userId, email) |
| HMAC-SHA256 | Hash-based Message Authentication Code — used to sign JWT |
| PBKDF2 | Password-Based Key Derivation Function — slow hashing for passwords |
| Salt | Random data added to password before hashing (prevents rainbow tables) |
| [Authorize] | Attribute requiring authentication on controller/action |
| [AllowAnonymous] | Override — allows unauthenticated access |
| Roles.Admin | String constant "Admin" — role check in [Authorize(Roles=...)] |
| Middleware | Component in the request pipeline that processes requests/responses |
| IMiddleware | Interface with InvokeAsync — used by GlobalExceptionMiddleware |
| RequestDelegate | The next middleware in the pipeline |
| CancellationToken | Allows cancellation of async operations (e.g., user closes tab) |
| IsolationLevel.Serializable | Strictest transaction isolation — prevents all concurrency anomalies |
| RowVersion | byte[] field used as optimistic concurrency token by EF Core |
| Soft Delete | IsDeleted flag instead of actually removing rows |
| Cascade Delete | Parent deleted → children automatically deleted |
| Restrict Delete | Cannot delete parent if children exist |
| CORS | Cross-Origin Resource Sharing — browser security policy |
| Swagger | Auto-generated interactive API documentation |
| DTO | Data Transfer Object — shapes data for API input/output |
| AutoMap | Map entity → DTO (we do it manually with Select/Map methods) |
| Expression<Func<T,bool>> | Lambda predicate translated to SQL WHERE clause |
| DbSeeder | Static class that creates initial data (Admin, Operator, Stops) |
| IConfiguration | Access to appsettings.json values (JWT key, connection string) |
| PendingOperator | Custom role for operators awaiting admin approval |
| AuditLog | Database table storing all admin/operator actions and errors |
| Stopwatch | .NET class for measuring elapsed time (used in AuditMiddleware) |

---

## Frontend Concepts — Complete List

| Concept | Definition |
|---|---|
| Angular | Google's TypeScript-based SPA framework |
| Component | Reusable UI building block with template + logic |
| Standalone Component | Component that declares its own imports, no NgModule |
| Template | HTML with Angular bindings (@if, @for, [class], (click)) |
| Signal | Angular's primitive for reactive state management |
| computed() | Derived signal that auto-updates when dependencies change |
| signal.set() | Replace signal value |
| signal.update() | Transform signal value with a function |
| Observable | RxJS stream of values over time (used for HTTP calls) |
| subscribe() | Start listening to an Observable |
| HttpClient | Angular service for making HTTP requests |
| HttpInterceptorFn | Functional interceptor to modify all HTTP requests/responses |
| Route Guard | CanActivateFn that controls route access |
| authGuard | Blocks unauthenticated users |
| noAuthGuard | Redirects already-logged-in users |
| roleGuard | Blocks users without required role |
| Lazy Loading | loadComponent — page JS only downloaded when navigated to |
| FormGroup | Collection of FormControls representing a form |
| FormArray | Array of FormGroups (passenger list) |
| FormBuilder | Service to create forms declaratively |
| Validators | Built-in: required, minLength, email, min, max |
| ReactiveFormsModule | Angular module for reactive forms |
| RouterLink | Directive for navigation links |
| RouterLinkActive | Adds CSS class when route is active |
| ActivatedRoute | Service to read current route params/queryParams |
| Router.navigate() | Programmatic navigation |
| @if / @for | Angular 17+ template control flow syntax |
| provideHttpClient() | Registers HttpClient in app.config.ts |
| withInterceptors() | Registers functional interceptors |
| provideRouter() | Registers router with routes array |
| environment.ts | Environment-specific config (apiUrl) |
| proxy.config.json | Dev server proxy to forward /api requests to backend |
| Tailwind CSS | Utility-first CSS framework (className strings) |
| TypeScript | Strongly-typed JavaScript superset |
| UserRole type | Union type: 'Customer' | 'Operator' | 'Admin' | 'PendingOperator' |
| BookingStateService | Singleton service holding in-progress booking data |
| AuditLogService | Service calling GET /api/auditlogs with filter params |
| OperatorApprovalService | Service calling operator approval endpoints |
| HttpParams | Angular class for building URL query parameters |
| catchError | RxJS operator for error handling in Observable pipelines |
| throwError | RxJS — re-throw error as Observable |
| BehaviorSubject vs Signal | Both hold state; Signal is simpler, no subscription needed |
| inject() | Angular's functional DI — get services in functions/interceptors |
| localStorage | Browser storage — persists across page refreshes |

---

# PART 4 — EXPECTED INTERVIEW QUESTIONS & ANSWERS

---

**Q: Why did you choose ASP.NET Core for the backend?**
A: ASP.NET Core 8 is one of the fastest web frameworks, has built-in dependency injection, native JWT support, EF Core integration, and runs cross-platform. For a .NET ecosystem, it's the clear choice.

**Q: Explain the Repository Pattern and why you used it.**
A: Repository Pattern abstracts database access behind an interface. Our `IRepository<T>` has methods like GetByIdAsync, FindAsync, AddAsync. Benefits: (1) Services don't depend on EF Core directly — they depend on the interface. (2) In unit tests, we mock the interface without touching the database. (3) One implementation `Repository<T>` covers all 10 entities — no duplicate code.

**Q: How does JWT authentication work in your project?**
A: On login, the server validates credentials, then creates a JWT containing the user's ID, username, role, and expiry time, signed with HMAC-SHA256 using a secret key. The client stores this token in localStorage. On subsequent requests, Angular's auth interceptor attaches it as `Authorization: Bearer <token>`. The backend validates the signature and expiry on every request, then populates `HttpContext.User` with the claims. Controllers use `[Authorize]` to require valid tokens and `[Authorize(Roles="Admin")]` for role-specific access.

**Q: How did you prevent double-seat booking?**
A: We use a Serializable database transaction in BookingService. This is the strictest isolation level — it prevents phantom reads (new rows appearing between two queries). Inside the transaction, we query existing bookings for the requested seats, and if any are taken, we throw an exception. The second concurrent request will either wait for the transaction to complete or fail with a conflict, so both requests cannot simultaneously succeed.

**Q: What is the difference between [Authorize] and [AllowAnonymous]?**
A: `[Authorize]` means the endpoint requires a valid JWT. Without one, the server returns 401 Unauthorized. `[AllowAnonymous]` explicitly allows unauthenticated access — it overrides any [Authorize] attributes from parent classes. We use AllowAnonymous on Login and Register endpoints since users don't have tokens yet.

**Q: What are Angular Signals and how are they different from RxJS?**
A: Signals are Angular's built-in synchronous reactive primitive. You create a `signal(initialValue)`, read it by calling `signal()`, and update with `.set()` or `.update()`. Computed signals auto-update when their dependencies change. RxJS Observables are asynchronous streams with operators (map, filter, etc.) — better for HTTP calls. Signals are simpler for UI state — no `.subscribe()`, no memory leaks from forgotten subscriptions.

**Q: What is the purpose of the AuditMiddleware?**
A: It runs on every HTTP request. After the response completes, if it was a write operation (POST/PUT/PATCH/DELETE) on an /api/ route, it writes an AuditLog record to the database with the username, role, endpoint, HTTP method, status code, and duration. If an unhandled exception occurs, it writes an Error log with the full stack trace. This gives admins a complete trail of all system activity and errors, viewable at /admin/audit-logs.

**Q: Explain the operator approval workflow.**
A: When a user registers with role "Operator", the backend assigns "PendingOperator" instead. They get a JWT with PendingOperator role, can log in, but frontend role guards block /operator routes. The admin sees a pending count on the dashboard and visits /admin/operator-approvals. They can approve (sets role to Operator, creates BusOperator profile with company name) or reject (sets role to Customer). The operator then logs in again and gets a new JWT with the Operator role, gaining full access.

**Q: What is CORS and how is it configured?**
A: CORS (Cross-Origin Resource Sharing) is a browser security policy that blocks JavaScript from calling APIs on different origins (domain:port combinations). Our Angular app runs on port 4200, the API on 5299 — different ports = different origins. We configure the backend with `policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()` for development. In production, we'd specify the exact frontend domain. The browser sends a preflight OPTIONS request; if CORS headers are present, the actual request proceeds.

**Q: What is `AsNoTracking()` and when do you use it?**
A: EF Core normally tracks every entity it loads in its change tracker — this lets it detect modifications and generate UPDATE SQL. For read-only operations (like listing all buses), we don't need change tracking. `AsNoTracking()` tells EF Core not to track these entities, making reads significantly faster and using less memory.

**Q: How does the Angular proxy work?**
A: In development, `proxy.config.json` tells Angular's dev server to intercept any request to `/api/*` and forward it to `http://localhost:5299`. So when our service calls `/api/buses`, Angular's Node.js dev server makes the actual call to `http://localhost:5299/api/buses` and returns the response. The browser only talks to port 4200 — no CORS issues.

**Q: What is the BaseEntity and why do all models extend it?**
A: BaseEntity is an abstract class providing common fields: GUID primary key (auto-generated), CreatedAtUtc, UpdatedAtUtc, IsDeleted (soft delete), and RowVersion (concurrency token). Extending it means we never forget these fields, and our generic Repository<T> can rely on the `Id` property existing on every entity.

**Q: What testing frameworks did you use and what was tested?**
A: Backend: xUnit for test runner, Moq for mocking dependencies. We tested BookingService, BusService, RouteService, ScheduleService, UserService, and TokenService — covering happy paths, validation errors, ownership checks, and edge cases. Frontend: Jasmine as the test framework, Karma as the test runner. We tested AuthService (login, logout, token expiry), AuditLogService (HTTP params, response mapping), route guards (all three guards), AuditLogsComponent (tabs, filters, pagination), and AdminDashboardComponent (data loading, formatRelative).

---

# PART 5 — ARCHITECTURE SUMMARY DIAGRAM (TEXT)

```
┌─────────────────────────────────────────────────────────────────────┐
│                         BROWSER                                      │
│  Angular 21 SPA (TypeScript + Tailwind CSS)                         │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────────┐   │
│  │ Customer │  │ Operator │  │  Admin   │  │  Auth Pages       │   │
│  │  Pages   │  │  Pages   │  │  Pages   │  │  Login / Register │   │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └──────┬───────────┘   │
│       │              │              │                │               │
│  ┌────▼──────────────▼──────────────▼────────────────▼───────────┐ │
│  │              Angular Services (HttpClient)                     │ │
│  │  BookingService  BusService  AuditLogService  AuthService      │ │
│  └────────────────────────┬──────────────────────────────────────┘ │
│                            │  HTTP + JWT Bearer Token               │
│             ┌──────────────┴─────────────────┐                     │
│             │   authInterceptor (adds token)  │                     │
│             └──────────────┬─────────────────┘                     │
└──────────────────────────────────────────────────────────────────────┘
                             │ /api/*  (proxied in dev)
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    ASP.NET Core 8 Web API                           │
│                                                                     │
│  Middleware Pipeline:                                               │
│  1. HTTPS Redirect                                                  │
│  2. CORS (AllowAny in dev)                                         │
│  3. AuditMiddleware (logs all writes to DB)                        │
│  4. GlobalExceptionMiddleware (handles unhandled exceptions)       │
│  5. Authentication (validates JWT, populates User claims)          │
│  6. Authorization (checks [Authorize] attributes)                  │
│                                                                     │
│  Controllers:                                                       │
│  AuthController  BusesController  BookingsController               │
│  SchedulesController  RoutesController  StopsController            │
│  AuditLogsController  OperatorApprovalController                   │
│                   │                                                 │
│  Services: (Business Logic)                                        │
│  UserService  BusService  RouteService  ScheduleService            │
│  BookingService  StopService  AuditLogService  TokenService        │
│  PasswordService                                                    │
│                   │                                                 │
│  IRepository<T> → Repository<T>                                    │
│                   │                                                 │
│  AppDbContext (EF Core)                                            │
│                   │                                                 │
└──────────────────────────────────────────────────────────────────────┘
                             │ SQL Queries
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      SQL Server Database                            │
│                                                                     │
│  Tables: Users, BusOperators, Buses, Stops, BusRoutes,            │
│          RouteStops, BusSchedules, Bookings, BookingPassengers,    │
│          Payments, AuditLogs                                        │
└─────────────────────────────────────────────────────────────────────┘
```

---

# PART 6 — 12-HOUR STUDY PLAN

**Hours 1-2: Backend Architecture**
- Read Chapter 2 (Program.cs), Chapter 3 (EF Core), Chapter 4 (BaseEntity)
- Understand the request pipeline, DI registration, middleware order

**Hours 3-4: Security Deep Dive**
- Read Chapter 6 (JWT), Chapter 7 (Passwords), Chapter 8 (Roles)
- Practice explaining the JWT flow from login to protected endpoint

**Hours 5-6: Core Business Logic**
- Read Chapter 5 (Repository), Chapter 9 (Booking), Chapter 10 (Audit)
- Focus on the 7-step booking validation and Serializable transaction

**Hours 7-8: Frontend Architecture**
- Read Chapter 12 (Angular), Chapter 13 (Signals), Chapter 14 (Interceptor)
- Understand the difference between Signals and RxJS

**Hours 9-10: Frontend Features**
- Read Chapter 15 (Guards), Chapter 16 (BookingState), Chapter 17 (Forms)
- Trace the full booking flow: search → seat → passenger → payment

**Hours 11-12: Q&A Practice**
- Go through all 14 Q&As in Part 4
- Practice explaining the operator approval flow end-to-end
- Review Part 5 architecture diagram

**Golden Rule:** If your teacher asks anything, trace it through the layers:
Browser → Interceptor → Angular Service → HTTP → Controller → Service → Repository → DB
